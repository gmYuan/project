export {default as createHashHistory} from './createHashHistory';
export {default as createBrowserHistory} from './createBrowserHistory';